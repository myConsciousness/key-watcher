from setuptools import setup

setup(
    name="keywatcher",
    version='1.0',
    description='',
    author='Kato Shinya',
    author_email='kato.shinya.dev@gmail.com',
    url='https://github.com/myConsciousness/key-watcher',
)
